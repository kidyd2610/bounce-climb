extends Node2D
## Game controller: infinite procedural platform generation, camera, lava, game flow.

const PlatformScript := preload("res://scripts/platform.gd")
const W := 1280.0

@onready var platforms: Node2D = $Platforms
@onready var player = $Player
@onready var cam: Camera2D = $Camera
@onready var lava = $Lava
@onready var bg = $BackgroundLayer/Background
@onready var fx = $FX

var cam_y := 360.0
var gen_y := 620.0
var last_x := 640.0
var start_y := 587.0
var min_y := 587.0
var rows := 0
var dead_time := 0.0
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	Game.reset()
	Game.fx = fx
	rng.randomize()
	lava.level = 940.0
	_spawn(PlatformScript.NORMAL, 640.0, 620.0, 520.0, false, false, 0.0)
	last_x = 640.0
	gen_y = 620.0
	_generate()
	cam.position = Vector2(W * 0.5, cam_y)


func _process(delta: float) -> void:
	if Game.state == Game.TITLE:
		if Input.is_action_just_pressed("jump") or Input.is_action_just_pressed("restart"):
			Game.state = Game.PLAYING
			Sfx.play("start")
	elif Game.state == Game.PLAYING:
		_tick_game(delta)
	elif Game.state == Game.DEAD:
		dead_time += delta
		if dead_time > 0.5 and (Input.is_action_just_pressed("jump") or Input.is_action_just_pressed("restart")):
			get_tree().reload_current_scene()
			return

	# camera only ever climbs
	if Game.state != Game.DEAD:
		var target: float = player.global_position.y - 130.0
		if target < cam_y:
			cam_y = lerpf(cam_y, target, 1.0 - exp(-10.0 * delta))
		cam_y = minf(cam_y, player.global_position.y + 290.0)
	Game.shake_amt *= exp(-9.0 * delta)
	cam.position = Vector2(W * 0.5, cam_y)
	cam.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * Game.shake_amt
	bg.cam_y = cam_y
	Game.lava_dist = lava.level - player.global_position.y

	_generate()
	_cleanup()


func _tick_game(delta: float) -> void:
	if Input.is_action_just_pressed("restart"):
		get_tree().reload_current_scene()
		return
	var py: float = player.global_position.y
	min_y = minf(min_y, py)
	Game.height = int((start_y - min_y) / 10.0)
	var m := float(Game.height)
	lava.level -= (55.0 + 150.0 * (1.0 - exp(-m / 500.0))) * delta
	var limit := cam_y + 470.0
	if lava.level > limit:
		lava.level = move_toward(lava.level, limit, 220.0 * delta)
	if py + 12.0 > lava.level or py > cam_y + 420.0:
		_die()


func _die() -> void:
	if Game.state != Game.PLAYING:
		return
	Game.finish()
	player.die()
	Sfx.play("die")
	Game.shake(14.0)
	dead_time = 0.0


# ------------------------------------------------------------ generation
func _generate() -> void:
	while gen_y > cam_y - 1200.0:
		_make_row()


func _make_row() -> void:
	rows += 1
	var gh := (start_y - gen_y) / 10.0
	var d := clampf(gh / 600.0, 0.0, 1.0) # difficulty 0..1
	gen_y -= rng.randf_range(92.0, 110.0 + 26.0 * d)
	var x := clampf(last_x + rng.randf_range(-1.0, 1.0) * (160.0 + 70.0 * d), 120.0, W - 120.0)
	var w := rng.randf_range(150.0 - 55.0 * d, 230.0 - 90.0 * d)
	var kind: int = PlatformScript.NORMAL
	var amp := 0.0
	if rows > 4:
		var r := rng.randf()
		var pm := 0.05 + 0.15 * d
		var pc := pm + 0.04 + 0.14 * d
		var pj := pc + 0.07
		if r < pm:
			kind = PlatformScript.MOVING
		elif r < pc:
			kind = PlatformScript.CRUMBLE
		elif r < pj:
			kind = PlatformScript.JELLY
	if kind == PlatformScript.MOVING:
		w = maxf(w, 130.0)
		amp = maxf(0.0, minf(rng.randf_range(70.0, 150.0), minf(x - 80.0, W - 80.0 - x)))
	var pad: bool = kind == PlatformScript.NORMAL and rows > 2 and rng.randf() < 0.11
	_spawn(kind, x, gen_y, w, pad, rng.randf() < 0.35, amp)
	last_x = x

	# optional side platform (bonus / bounce opportunity)
	if rng.randf() < 0.28:
		var side := -1.0 if x > W * 0.5 else 1.0
		var ex := x + side * rng.randf_range(280.0, 420.0)
		if ex < 100.0 or ex > W - 100.0:
			ex = x - side * rng.randf_range(280.0, 420.0)
		if ex >= 100.0 and ex <= W - 100.0:
			var choices := [PlatformScript.JELLY, PlatformScript.NORMAL, PlatformScript.CRUMBLE]
			var ek: int = choices.pick_random()
			_spawn(ek, ex, gen_y + rng.randf_range(-25.0, 25.0), rng.randf_range(100.0, 150.0),
				ek == PlatformScript.NORMAL and rng.randf() < 0.3, true, 0.0)


func _spawn(kind: int, x: float, y: float, w: float, pad: bool, coin: bool, amp: float) -> void:
	var p = PlatformScript.new()
	p.setup(kind, x, y, w)
	p.has_pad = pad
	p.with_coin = coin
	p.amp = amp
	platforms.add_child(p)


func _cleanup() -> void:
	var limit := cam_y + 760.0
	for p in platforms.get_children():
		if p.global_position.y > limit:
			p.queue_free()
