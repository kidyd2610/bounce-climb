extends CharacterBody2D
## Bouncy hero: walk / run / jump (variable height) / HIGH JUMP / air DASH.

const GRAVITY := 2800.0
const WALK_SPEED := 380.0
const RUN_SPEED := 640.0
const ACCEL := 3800.0
const AIR_ACCEL := 2600.0
const FRICTION := 3000.0
const JUMP_V := -925.0
const HIGH_JUMP_V := -1300.0
const MAX_FALL := 1750.0
const DASH_SPEED := 1350.0
const DASH_TIME := 0.17
const DASH_COOLDOWN := 0.22
const COYOTE := 0.1
const BUFFER := 0.12
const HIGH_JUMP_CD := 1.0
const WORLD_W := 1280.0

var coyote := 0.0
var jump_buf := 0.0
var hj_buf := 0.0
var hj_cd := 0.0
var dash_t := 0.0
var dash_cd := 0.0
var dash_dir := 1.0
var dash_ok := true
var cuttable := false
var face := 1.0
var sq := Vector2.ONE
var fx_timer := 0.0
var t := 0.0
var dead := false


func _physics_process(delta: float) -> void:
	t += delta
	if Game.state != Game.PLAYING or dead:
		return

	var dir := Input.get_axis("move_left", "move_right")
	var max_speed := RUN_SPEED if Input.is_action_pressed("run") else WALK_SPEED
	var on_floor := is_on_floor()
	if absf(dir) > 0.1:
		face = signf(dir)

	coyote = COYOTE if on_floor else maxf(0.0, coyote - delta)
	jump_buf = maxf(0.0, jump_buf - delta)
	hj_buf = maxf(0.0, hj_buf - delta)
	hj_cd = maxf(0.0, hj_cd - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	if Input.is_action_just_pressed("jump"):
		jump_buf = BUFFER
	if Input.is_action_just_pressed("high_jump"):
		hj_buf = BUFFER
	if on_floor and dash_t <= 0.0:
		dash_ok = true

	# ---- jumps
	if jump_buf > 0.0 and coyote > 0.0:
		_jump(JUMP_V, true, "jump")
	elif hj_buf > 0.0 and coyote > 0.0 and hj_cd <= 0.0:
		_jump(HIGH_JUMP_V, false, "high")
		hj_cd = HIGH_JUMP_CD
		if Game.fx:
			Game.fx.ring(global_position + Vector2(0, 22), Color("7df9ff"), 80.0, 0.4)

	# ---- dash
	if Input.is_action_just_pressed("dash") and dash_ok and dash_cd <= 0.0 and dash_t <= 0.0:
		dash_t = DASH_TIME
		dash_cd = DASH_COOLDOWN
		dash_ok = false
		dash_dir = signf(dir) if absf(dir) > 0.1 else face
		Sfx.play("dash")
		Game.shake(3.0)

	# ---- variable jump height
	if cuttable:
		if velocity.y >= 0.0:
			cuttable = false
		elif Input.is_action_just_released("jump"):
			velocity.y *= 0.45
			cuttable = false

	if dash_t > 0.0:
		dash_t -= delta
		velocity.x = dash_dir * DASH_SPEED
		velocity.y = 0.0
		if Game.fx:
			Game.fx.ghost(global_position, Color(1.0, 0.8, 0.3), 22.0, 0.25)
		if dash_t <= 0.0:
			velocity.x = dash_dir * RUN_SPEED * 1.15
	else:
		var g := GRAVITY
		if velocity.y > 0.0:
			g *= 1.25
		elif absf(velocity.y) < 140.0 and Input.is_action_pressed("jump"):
			g *= 0.65
		velocity.y = minf(velocity.y + g * delta, MAX_FALL)
		var accel := ACCEL if on_floor else AIR_ACCEL
		if absf(dir) > 0.1:
			if signf(velocity.x) != signf(dir) and absf(velocity.x) > 10.0:
				accel *= 1.6
			velocity.x = move_toward(velocity.x, dir * max_speed, accel * delta)
		else:
			velocity.x = move_toward(velocity.x, 0.0, (FRICTION if on_floor else 500.0) * delta)

	var pre_vy := velocity.y
	move_and_slide()

	var now_floor := is_on_floor()
	if now_floor:
		var landed := not on_floor
		if landed:
			sq = Vector2(1.35, 0.7)
			Sfx.play("land", randf_range(0.9, 1.1), -10.0)
			_dust(6)
			if pre_vy > 900.0:
				Game.shake(3.0)
		for i in get_slide_collision_count():
			var col := get_slide_collision(i)
			if col.get_normal().y < -0.6:
				var o = col.get_collider()
				if o != null and o.has_method("stood_on"):
					o.stood_on(self, landed)
				break

	# screen wrap (arcade style)
	if position.x < -24.0:
		position.x = WORLD_W + 24.0
	elif position.x > WORLD_W + 24.0:
		position.x = -24.0

	# trails
	fx_timer -= delta
	if fx_timer <= 0.0:
		fx_timer = 0.03
		if absf(velocity.y) > 950.0 and Game.fx:
			Game.fx.ghost(global_position, Color("ffd23f") if velocity.y < 0.0 else Color("7df9ff"), 16.0, 0.22)
		elif now_floor and absf(velocity.x) > 400.0:
			_dust(1)


func _jump(v: float, cut: bool, sound: String) -> void:
	velocity.y = v
	cuttable = cut
	jump_buf = 0.0
	hj_buf = 0.0
	coyote = 0.0
	dash_t = 0.0
	sq = Vector2(0.7, 1.35)
	Sfx.play(sound, randf_range(0.95, 1.05))
	_dust(5)


## Called by bounce pads / jelly platforms.
func launch(force: float, col: Color) -> void:
	velocity.y = -force
	cuttable = false
	dash_ok = true
	coyote = 0.0
	dash_t = 0.0
	Game.add_combo()
	sq = Vector2(0.62, 1.5)
	Sfx.play("bounce", 0.85 + minf(float(Game.combo), 10.0) * 0.07, -3.0)
	Game.shake(5.0)
	if Game.fx:
		Game.fx.ring(global_position + Vector2(0, 22), col, 90.0, 0.45)
		Game.fx.burst(global_position + Vector2(0, 22), col, 18, 380.0, 0.6, 5.0, 700.0)


func _dust(n: int) -> void:
	if Game.fx:
		Game.fx.burst(global_position + Vector2(0, 22), Color(1, 1, 1, 0.6), n, 120.0, 0.35, 4.0, -30.0)


func die() -> void:
	dead = true
	visible = false
	if Game.fx:
		Game.fx.burst(global_position, Color("ffd23f"), 36, 520.0, 1.0, 7.0, 900.0)
		Game.fx.burst(global_position, Color("ff3b5c"), 20, 420.0, 0.9, 6.0, 900.0)
		Game.fx.ring(global_position, Color("ff3b5c"), 140.0, 0.6)


func _process(delta: float) -> void:
	var target := Vector2.ONE
	if Game.state == Game.PLAYING and not is_on_floor():
		var st := clampf(absf(velocity.y) / 2600.0, 0.0, 0.22)
		target = Vector2(1.0 / (1.0 + st), 1.0 + st)
	if dash_t > 0.0:
		target = Vector2(1.3, 0.8)
	sq = sq.lerp(target, 1.0 - exp(-14.0 * delta))
	Game.dash_ready = dash_ok and dash_cd <= 0.0
	Game.hj_ratio = 1.0 - hj_cd / HIGH_JUMP_CD
	queue_redraw()


func _draw() -> void:
	if dead:
		return
	var bob := 0.0
	if Game.state == Game.TITLE:
		bob = absf(sin(t * 4.0)) * -16.0
	draw_circle(Vector2(0, bob), 36.0, Color(1.0, 0.75, 0.25, 0.08))
	draw_circle(Vector2(0, bob), 29.0, Color(1.0, 0.75, 0.25, 0.14))
	if dash_t > 0.0:
		for i in 4:
			var ly := -14.0 + float(i) * 9.0
			draw_line(Vector2(-dash_dir * 30.0, ly), Vector2(-dash_dir * (62.0 + float(i) * 10.0), ly), Color(1, 1, 1, 0.6), 3.0)

	draw_set_transform(Vector2(0.0, 22.0 + bob), 0.0, sq)
	var c := Vector2(0.0, -22.0)
	var f := face
	# shoes
	draw_circle(Vector2(-10.0, -3.0), 7.0, Color("7a1230"))
	draw_circle(Vector2(10.0, -3.0), 7.0, Color("7a1230"))
	# body
	draw_circle(c, 22.0, Color("a64b00"))
	draw_circle(c, 20.5, Color("ff9f1c"))
	draw_circle(c + Vector2(0, 5), 14.0, Color("ffb84d"))
	draw_circle(c + Vector2(-8, -8), 5.0, Color(1, 1, 1, 0.45))
	# cap
	var cc := c + Vector2(0.0, -5.0)
	var cap := PackedVector2Array()
	for i in 13:
		var a := PI + PI * float(i) / 12.0
		cap.append(cc + Vector2(cos(a) * 21.5, sin(a) * 19.0))
	draw_colored_polygon(cap, Color("ff3b5c"))
	draw_colored_polygon(PackedVector2Array([cc + Vector2(f * 6.0, -1.0), cc + Vector2(f * 27.0, 1.0), cc + Vector2(f * 27.0, 6.0), cc + Vector2(f * 6.0, 6.0)]), Color("d41f45"))
	draw_circle(cc + Vector2(f * 2.0, -11.0), 5.0, Color.WHITE)
	# eyes
	var ey := c + Vector2(f * 4.0, 4.0)
	for sgn in [-1.0, 1.0]:
		var ep: Vector2 = ey + Vector2(sgn * 6.0, 0.0)
		draw_circle(ep, 5.2, Color.WHITE)
		draw_circle(ep + Vector2(f * 1.8, clampf(velocity.y / 600.0, -1.5, 1.5)), 2.6, Color("1b1033"))
	draw_arc(c + Vector2(f * 4.0, 11.0), 5.0, 0.3, PI - 0.3, 8, Color("5a2a00"), 2.0, true)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
