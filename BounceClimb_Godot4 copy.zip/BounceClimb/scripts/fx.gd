extends Node2D
## Lightweight particle system: dots, expanding rings and ghost trails.

class Particle:
	var pos := Vector2.ZERO
	var vel := Vector2.ZERO
	var color := Color.WHITE
	var life := 1.0
	var max_life := 1.0
	var size := 4.0
	var grav := 0.0
	var kind := 0 # 0 dot, 1 ring, 2 ghost
	var radius := 0.0

const MAX_PARTS := 700
var parts: Array[Particle] = []


func _add(p: Particle) -> void:
	if parts.size() < MAX_PARTS:
		parts.append(p)


func burst(pos: Vector2, color: Color, count: int = 12, speed: float = 260.0, life: float = 0.6, size: float = 5.0, gravity: float = 900.0) -> void:
	for i in count:
		var p := Particle.new()
		var a := randf() * TAU
		p.pos = pos
		p.vel = Vector2(cos(a), sin(a)) * speed * randf_range(0.3, 1.0)
		p.color = color
		p.life = life * randf_range(0.6, 1.0)
		p.max_life = life
		p.size = size * randf_range(0.6, 1.2)
		p.grav = gravity
		_add(p)


func ring(pos: Vector2, color: Color, radius: float = 80.0, life: float = 0.4) -> void:
	var p := Particle.new()
	p.pos = pos
	p.color = color
	p.life = life
	p.max_life = life
	p.kind = 1
	p.radius = radius
	_add(p)


func ghost(pos: Vector2, color: Color, size: float = 22.0, life: float = 0.25) -> void:
	var p := Particle.new()
	p.pos = pos
	p.color = color
	p.life = life
	p.max_life = life
	p.size = size
	p.kind = 2
	_add(p)


func _process(delta: float) -> void:
	var i := parts.size() - 1
	while i >= 0:
		var p := parts[i]
		p.life -= delta
		if p.life <= 0.0:
			parts.remove_at(i)
		else:
			p.vel.y += p.grav * delta
			p.pos += p.vel * delta
		i -= 1
	queue_redraw()


func _draw() -> void:
	for p in parts:
		var t := p.life / p.max_life
		var a := p.color.a * t
		if p.kind == 0:
			draw_circle(p.pos, maxf(0.5, p.size * t), Color(p.color, a))
		elif p.kind == 1:
			var r := p.radius * (1.0 - t * t)
			draw_arc(p.pos, r, 0.0, TAU, 40, Color(p.color, a), 2.0 + 5.0 * t, true)
		else:
			draw_circle(p.pos, p.size, Color(p.color, a * 0.45))
