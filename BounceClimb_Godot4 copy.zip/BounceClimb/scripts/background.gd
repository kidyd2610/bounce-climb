extends Node2D
## Parallax gradient sky that shifts colour zones as you climb.

const W := 1280.0
const H := 720.0

var cam_y: float = 360.0
var t: float = 0.0
var zones := [
	[Color("0b0830"), Color("43208f")],
	[Color("06193a"), Color("0e7490")],
	[Color("2d0b4a"), Color("ff5d73")],
	[Color("01010a"), Color("2a0f55")],
	[Color("031c22"), Color("1fa37a")],
]


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _zone_colors() -> Array:
	var hm := maxf(0.0, (587.0 - cam_y) / 10.0)
	var f := hm / 150.0
	var i := int(floor(f))
	var k := smoothstep(0.55, 1.0, f - float(i))
	var a: Array = zones[i % zones.size()]
	var b: Array = zones[(i + 1) % zones.size()]
	return [a[0].lerp(b[0], k), a[1].lerp(b[1], k)]


func _draw() -> void:
	var zc := _zone_colors()
	var top: Color = zc[0]
	var bot: Color = zc[1]
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(W, 0), Vector2(W, H), Vector2(0, H)]),
		PackedColorArray([top, top, bot, bot]))
	# moon
	var moon := Vector2(1010.0, 160.0 + sin(t * 0.5) * 6.0)
	draw_circle(moon, 110.0, Color(1, 1, 1, 0.04))
	draw_circle(moon, 80.0, Color(1, 1, 1, 0.07))
	draw_circle(moon, 56.0, Color(1.0, 0.95, 0.85, 0.35))
	# stars
	for i in 90:
		var par := 0.03 + float(i % 3) * 0.035
		var sx := fposmod(float(i) * 137.508, W)
		var sy := fposmod(float(i) * 309.015 - cam_y * par, H)
		var tw := 0.5 + 0.5 * sin(t * 2.0 + float(i))
		draw_circle(Vector2(sx, sy), 1.0 + float(i % 3) * 0.6, Color(1, 1, 1, 0.3 + 0.5 * tw))
	# bouncing orbs
	var tint := bot.lightened(0.35)
	for i in 14:
		var par := 0.12 + float(i % 4) * 0.07
		var ox := fposmod(float(i) * 233.3 + 80.0, W)
		var oy := fposmod(float(i) * 151.7 - cam_y * par, H + 240.0) - 120.0
		oy -= absf(sin(t * 1.4 + float(i) * 1.3)) * 50.0
		var r := 26.0 + float(i % 5) * 14.0
		draw_circle(Vector2(ox, oy), r, Color(tint, 0.10))
		draw_arc(Vector2(ox, oy), r, 0.0, TAU, 40, Color(tint, 0.35), 2.0, true)
		draw_circle(Vector2(ox - r * 0.3, oy - r * 0.3), r * 0.18, Color(1, 1, 1, 0.25))
