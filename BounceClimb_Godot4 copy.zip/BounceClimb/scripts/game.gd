extends Node
## Global game state, input map setup, score and save data.

const TITLE := 0
const PLAYING := 1
const DEAD := 2
const SAVE_PATH := "user://bounce_climb.cfg"

var state: int = TITLE
var height: int = 0
var coins: int = 0
var combo: int = 0
var bonus: int = 0
var best: int = 0
var fx = null
var shake_amt: float = 0.0
var dash_ready: bool = true
var hj_ratio: float = 1.0
var lava_dist: float = 9999.0


func _ready() -> void:
	_setup_input()
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		best = int(cfg.get_value("save", "best", 0))


func reset() -> void:
	state = TITLE
	height = 0
	coins = 0
	combo = 0
	bonus = 0
	shake_amt = 0.0
	fx = null
	dash_ready = true
	hj_ratio = 1.0
	lava_dist = 9999.0


func get_score() -> int:
	return height * 10 + bonus


func add_coin() -> void:
	coins += 1
	bonus += 50 * maxi(1, combo)


func add_combo() -> void:
	combo += 1
	if combo >= 2:
		bonus += 25 * combo


func reset_combo() -> void:
	combo = 0


func shake(amount: float) -> void:
	shake_amt = maxf(shake_amt, amount)


func finish() -> void:
	state = DEAD
	if get_score() > best:
		best = get_score()
		var cfg := ConfigFile.new()
		cfg.set_value("save", "best", best)
		cfg.save(SAVE_PATH)


# ---------------------------------------------------------------- input
func _setup_input() -> void:
	_keys("move_left", [KEY_A, KEY_LEFT])
	_keys("move_right", [KEY_D, KEY_RIGHT])
	_keys("jump", [KEY_SPACE, KEY_W, KEY_UP])
	_keys("high_jump", [KEY_Z, KEY_K])
	_keys("dash", [KEY_X, KEY_J])
	_keys("run", [KEY_SHIFT])
	_keys("restart", [KEY_R, KEY_ENTER])
	_btn("jump", JOY_BUTTON_A)
	_btn("high_jump", JOY_BUTTON_Y)
	_btn("dash", JOY_BUTTON_X)
	_btn("dash", JOY_BUTTON_B)
	_btn("run", JOY_BUTTON_RIGHT_SHOULDER)
	_btn("restart", JOY_BUTTON_START)
	_btn("move_left", JOY_BUTTON_DPAD_LEFT)
	_btn("move_right", JOY_BUTTON_DPAD_RIGHT)
	_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_axis("run", JOY_AXIS_TRIGGER_RIGHT, 1.0)


func _ensure(action: String) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.5)


func _keys(action: String, codes: Array) -> void:
	_ensure(action)
	for c in codes:
		var e := InputEventKey.new()
		e.physical_keycode = c as Key
		InputMap.action_add_event(action, e)


func _btn(action: String, button: JoyButton) -> void:
	_ensure(action)
	var e := InputEventJoypadButton.new()
	e.button_index = button
	InputMap.action_add_event(action, e)


func _axis(action: String, axis: JoyAxis, value: float) -> void:
	_ensure(action)
	var e := InputEventJoypadMotion.new()
	e.axis = axis
	e.axis_value = value
	InputMap.action_add_event(action, e)
