extends Node
## Procedurally synthesized sound effects (no audio assets needed).

const RATE := 22050
var sounds: Dictionary = {}
var voices: Array[AudioStreamPlayer] = []
var idx := 0


func _ready() -> void:
	for i in 10:
		var p := AudioStreamPlayer.new()
		add_child(p)
		voices.append(p)
	sounds["jump"] = _synth(320.0, 640.0, 0.15, 0.45, 0, 0.0)
	sounds["high"] = _synth(260.0, 1000.0, 0.3, 0.5, 0, 0.0)
	sounds["bounce"] = _synth(180.0, 520.0, 0.35, 0.55, 0, 0.25)
	sounds["land"] = _synth(160.0, 70.0, 0.1, 0.5, 0, 0.0)
	sounds["coin"] = _synth(880.0, 1320.0, 0.14, 0.35, 1, 0.0)
	sounds["die"] = _synth(520.0, 50.0, 0.8, 0.5, 1, 0.1)
	sounds["start"] = _synth(300.0, 900.0, 0.25, 0.4, 1, 0.0)
	sounds["dash"] = _noise(0.2, 0.35)
	sounds["crumble"] = _noise(0.3, 0.4)


func play(sound: String, pitch: float = 1.0, vol_db: float = -4.0) -> void:
	if not sounds.has(sound):
		return
	var p := voices[idx]
	idx = (idx + 1) % voices.size()
	p.stream = sounds[sound]
	p.pitch_scale = pitch
	p.volume_db = vol_db
	p.play()


func _synth(f0: float, f1: float, dur: float, vol: float, shape: int, vib: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		var f := lerpf(f0, f1, t) * (1.0 + vib * sin(t * 50.0))
		phase += f / float(RATE)
		var s := sin(phase * TAU)
		if shape == 1:
			s = 0.6 if fposmod(phase, 1.0) < 0.5 else -0.6
		var env := (1.0 - t) * minf(1.0, t * 40.0)
		data.encode_s16(i * 2, int(clampf(s * env * vol, -1.0, 1.0) * 32767.0))
	return _wrap(data)


func _noise(dur: float, vol: float) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var last := 0.0
	for i in n:
		var t := float(i) / float(n)
		last = lerpf(last, randf_range(-1.0, 1.0), 0.3)
		var env := sin(t * PI)
		data.encode_s16(i * 2, int(clampf(last * env * vol * 2.0, -1.0, 1.0) * 32767.0))
	return _wrap(data)


func _wrap(data: PackedByteArray) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	return w
