extends Area2D
## Spinning collectible coin.

var t: float = 0.0
var taken: bool = false


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1
	var cs := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 20.0
	cs.shape = c
	add_child(cs)
	body_entered.connect(_on_body)
	t = randf() * 6.0


func _on_body(body: Node) -> void:
	if taken or not body.is_in_group("player"):
		return
	taken = true
	Game.add_coin()
	Sfx.play("coin", 1.0 + float(Game.coins % 8) * 0.05)
	if Game.fx:
		Game.fx.burst(global_position, Color("ffe066"), 14, 260.0, 0.5, 4.0, 300.0)
		Game.fx.ring(global_position, Color("ffe066"), 40.0, 0.3)
	queue_free()


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _draw() -> void:
	var bob := sin(t * 3.0) * 3.0
	var sx := absf(cos(t * 3.5)) * 0.8 + 0.2
	draw_circle(Vector2(0, bob), 26.0, Color(1, 0.85, 0.3, 0.12))
	draw_set_transform(Vector2(0, bob), 0.0, Vector2(sx, 1.0))
	draw_circle(Vector2.ZERO, 14.0, Color("b8860b"))
	draw_circle(Vector2.ZERO, 12.0, Color("ffd23f"))
	draw_circle(Vector2.ZERO, 8.0, Color("ffe98a"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
