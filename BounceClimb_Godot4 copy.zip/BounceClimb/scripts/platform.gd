extends AnimatableBody2D
## Procedurally spawned platform. One-way collision. Types:
## NORMAL, MOVING (sine sweep), CRUMBLE (falls after you land), JELLY (auto-bounce).
## Any NORMAL platform may carry a spring pad.

const NORMAL := 0
const MOVING := 1
const CRUMBLE := 2
const JELLY := 3
const THICK := 22.0
const PAD_FORCE := 1677.0
const JELLY_FORCE := 1125.0
const CoinScript := preload("res://scripts/coin.gd")

var kind: int = NORMAL
var width: float = 160.0
var base_x: float = 0.0
var amp: float = 0.0
var speed: float = 1.0
var phase: float = 0.0
var has_pad: bool = false
var pad_x: float = 0.0
var pad_anim: float = 0.0
var wobble: float = 0.0
var with_coin: bool = false
var t: float = 0.0
var crumble_state: int = 0
var crumble_timer: float = 0.0
var drop_y: float = 0.0
var fall_vel: float = 0.0
var shape_node: CollisionShape2D
var sb := StyleBoxFlat.new()


func setup(p_kind: int, p_x: float, p_y: float, p_width: float) -> void:
	kind = p_kind
	width = p_width
	base_x = p_x
	position = Vector2(p_x, p_y)
	phase = randf() * TAU
	speed = randf_range(0.9, 1.7)


func _ready() -> void:
	collision_layer = 2
	collision_mask = 0
	shape_node = CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(width, THICK)
	shape_node.shape = r
	shape_node.one_way_collision = true
	shape_node.one_way_collision_margin = 5.0
	add_child(shape_node)
	sb.set_corner_radius_all(9)
	if has_pad:
		pad_x = randf_range(-width * 0.5 + 36.0, width * 0.5 - 36.0)
	if with_coin:
		var c := CoinScript.new()
		c.position = Vector2(randf_range(-width * 0.3, width * 0.3), -54.0)
		add_child(c)


## Called by the player every physics frame while standing on this platform.
func stood_on(p, landed: bool) -> void:
	if has_pad and absf(p.global_position.x - (global_position.x + pad_x)) < 36.0:
		pad_anim = 1.0
		var f := PAD_FORCE + (254.0 if Input.is_action_pressed("jump") else 0.0)
		p.launch(f, Color("ff4d6d"))
		return
	if kind == JELLY:
		wobble = 1.0
		var f2 := JELLY_FORCE + (265.0 if Input.is_action_pressed("jump") else 0.0)
		p.launch(f2, Color("ff5fa8"))
		return
	if landed:
		Game.reset_combo()
	if kind == CRUMBLE and crumble_state == 0:
		crumble_state = 1
		crumble_timer = 0.5
		Sfx.play("crumble", 1.4, -12.0)


func _physics_process(delta: float) -> void:
	t += delta
	if kind == MOVING:
		position.x = base_x + sin(t * speed + phase) * amp
	if kind == CRUMBLE:
		if crumble_state == 1:
			crumble_timer -= delta
			if crumble_timer <= 0.0:
				crumble_state = 2
				shape_node.disabled = true
				if Game.fx:
					Game.fx.burst(global_position, Color("d49a6a"), 16, 220.0, 0.6, 5.0, 900.0)
		elif crumble_state == 2:
			fall_vel += 1800.0 * delta
			drop_y += fall_vel * delta
			if drop_y > 900.0:
				queue_free()


func _process(delta: float) -> void:
	pad_anim = maxf(0.0, pad_anim - delta * 3.0)
	wobble = maxf(0.0, wobble - delta * 1.6)
	queue_redraw()


func _col() -> Color:
	if kind == MOVING:
		return Color("ffb02e")
	if kind == CRUMBLE:
		return Color("d49a6a")
	if kind == JELLY:
		return Color("ff5fa8")
	return Color("35e6c4")


func _draw() -> void:
	var col := _col()
	var off := Vector2(0.0, drop_y)
	if crumble_state == 1:
		off.x = sin(t * 80.0) * 2.5
	var h := THICK
	var y0 := -THICK * 0.5
	if kind == JELLY:
		h = THICK * (1.0 + 0.45 * wobble * sin(t * 26.0))
		y0 = THICK * 0.5 - h
	var rect := Rect2(-width * 0.5 + off.x, y0 + off.y, width, h)
	# glow
	sb.bg_color = Color(col, 0.08)
	draw_style_box(sb, rect.grow(12.0))
	sb.bg_color = Color(col, 0.14)
	draw_style_box(sb, rect.grow(6.0))
	# body
	sb.bg_color = Color(col, 0.85) if kind == JELLY else col.darkened(0.6)
	draw_style_box(sb, rect)
	sb.bg_color = col
	draw_style_box(sb, Rect2(rect.position, Vector2(width, minf(10.0, h))))
	draw_line(rect.position + Vector2(10, 3), rect.position + Vector2(width - 10.0, 3), Color(1, 1, 1, 0.55), 2.0)
	var ty := rect.position.y
	if kind == NORMAL:
		var n := int(width / 28.0)
		for i in n:
			draw_circle(Vector2(-width * 0.5 + 18.0 + float(i) * 28.0 + off.x, ty + 16.0), 2.5, col.darkened(0.2))
	elif kind == MOVING:
		for i in 3:
			var x := float(i - 1) * 24.0 + off.x
			draw_polyline(PackedVector2Array([Vector2(x - 5, ty + 12), Vector2(x + 3, ty + 16), Vector2(x - 5, ty + 20)]), col, 2.5, true)
	elif kind == CRUMBLE:
		var cc := Color(0.2, 0.1, 0.05, 0.8) if crumble_state == 0 else Color(1, 0.9, 0.6, 0.9)
		draw_polyline(PackedVector2Array([Vector2(-width * 0.25 + off.x, ty + 4), Vector2(-width * 0.2 + off.x, ty + 12), Vector2(-width * 0.3 + off.x, ty + 19)]), cc, 2.0)
		draw_polyline(PackedVector2Array([Vector2(width * 0.2 + off.x, ty + 3), Vector2(width * 0.27 + off.x, ty + 11), Vector2(width * 0.22 + off.x, ty + 19)]), cc, 2.0)
	elif kind == JELLY:
		draw_circle(Vector2(-width * 0.3 + off.x, ty + h * 0.6), 3.0, Color(1, 1, 1, 0.5))
		draw_circle(Vector2(width * 0.15 + off.x, ty + h * 0.65), 2.0, Color(1, 1, 1, 0.5))
	# spring pad
	if has_pad:
		var px := pad_x + off.x
		var sh := 14.0 + 14.0 * pad_anim
		var cap_y := ty - sh
		draw_rect(Rect2(px - 18.0, ty - 3.0, 36.0, 4.0), Color("7a1f3a"))
		var pts := PackedVector2Array()
		for i in 7:
			var yy := lerpf(ty - 2.0, cap_y + 4.0, float(i) / 6.0)
			pts.append(Vector2(px + (10.0 if i % 2 == 0 else -10.0), yy))
		draw_polyline(pts, Color("dfe6ee"), 3.0, true)
		sb.bg_color = Color(1.0, 0.3, 0.42, 0.25)
		draw_style_box(sb, Rect2(px - 30.0, cap_y - 12.0, 60.0, 20.0))
		sb.bg_color = Color("ff4d6d")
		draw_style_box(sb, Rect2(px - 24.0, cap_y - 6.0, 48.0, 8.0))
		draw_line(Vector2(px - 18.0, cap_y - 4.0), Vector2(px + 18.0, cap_y - 4.0), Color(1, 1, 1, 0.6), 2.0)
