extends Node2D
## The rising "Bounce Goo" lava that chases the player.

var level: float = 940.0
var t: float = 0.0


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _wave_y(x: float) -> float:
	return level + sin(x * 0.02 + t * 2.0) * 8.0 + sin(x * 0.047 - t * 3.1) * 5.0


func _draw() -> void:
	var x0 := -40.0
	var x1 := 1320.0
	var n := 64
	var hot := Color(1.0, 0.82, 0.3)
	var mid := Color(0.95, 0.25, 0.2)
	var deep := Color(0.5, 0.06, 0.2)
	# warning haze above the surface
	draw_polygon(PackedVector2Array([Vector2(x0, level - 140.0), Vector2(x1, level - 140.0), Vector2(x1, level), Vector2(x0, level)]),
		PackedColorArray([Color(1, 0.3, 0.2, 0.0), Color(1, 0.3, 0.2, 0.0), Color(1, 0.35, 0.2, 0.28), Color(1, 0.35, 0.2, 0.28)]))
	# gradient strip following the wave
	var surface := PackedVector2Array()
	for i in n + 1:
		var x := lerpf(x0, x1, float(i) / float(n))
		surface.append(Vector2(x, _wave_y(x)))
	for i in n:
		var a := surface[i]
		var b := surface[i + 1]
		draw_polygon(PackedVector2Array([a, b, b + Vector2(0, 70), a + Vector2(0, 70)]), PackedColorArray([hot, hot, mid, mid]))
	draw_rect(Rect2(x0, level + 70.0 + 14.0, x1 - x0, 1400.0), deep)
	draw_rect(Rect2(x0, level + 60.0, x1 - x0, 30.0), mid.darkened(0.2))
	# glowing rim
	draw_polyline(surface, Color(1, 0.7, 0.3, 0.25), 18.0, true)
	draw_polyline(surface, Color(1.0, 0.95, 0.6, 0.95), 4.0, true)
	# bouncing lava drops
	for i in 12:
		var bx := fposmod(float(i) * 117.3 + 40.0, 1280.0)
		var h := absf(sin(t * 2.0 + float(i) * 1.7))
		var by := _wave_y(bx) - h * (50.0 + float(i % 4) * 22.0)
		draw_circle(Vector2(bx, by), 7.0 + float(i % 3) * 2.0, Color(1.0, 0.6, 0.2, 0.9))
		draw_circle(Vector2(bx - 2.0, by - 2.0), 2.5, Color(1, 1, 0.8, 0.9))
