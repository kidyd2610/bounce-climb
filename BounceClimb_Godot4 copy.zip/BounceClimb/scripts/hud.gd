extends CanvasLayer
## Heads-up display, title screen and game-over screen (all drawn in code).

var ctl: Control
var t := 0.0
var last_combo := 0
var pop := 0.0
var sb := StyleBoxFlat.new()


func _ready() -> void:
	layer = 20
	ctl = Control.new()
	ctl.size = Vector2(1280, 720)
	ctl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ctl)
	ctl.draw.connect(_on_draw)


func _process(delta: float) -> void:
	t += delta
	if Game.combo != last_combo:
		if Game.combo > last_combo:
			pop = 1.0
		last_combo = Game.combo
	pop = maxf(0.0, pop - delta * 3.0)
	ctl.queue_redraw()


func _txt(s: String, pos: Vector2, size: int, col: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	var f := ThemeDB.fallback_font
	ctl.draw_string_outline(f, pos, s, align, width, size, 6, Color(0.05, 0.02, 0.15, 0.9))
	ctl.draw_string(f, pos, s, align, width, size, col)


func _panel(rect: Rect2, col: Color, radius: int = 12) -> void:
	sb.set_corner_radius_all(radius)
	sb.bg_color = col
	ctl.draw_style_box(sb, rect)


func _on_draw() -> void:
	if Game.state == Game.TITLE:
		_title()
	else:
		_hud()
	if Game.state == Game.DEAD:
		_gameover()


func _hud() -> void:
	# lava danger vignette
	if Game.state == Game.PLAYING and Game.lava_dist < 300.0:
		var a := (1.0 - Game.lava_dist / 300.0) * 0.5
		ctl.draw_polygon(PackedVector2Array([Vector2(0, 500), Vector2(1280, 500), Vector2(1280, 720), Vector2(0, 720)]),
			PackedColorArray([Color(1, 0.1, 0.1, 0.0), Color(1, 0.1, 0.1, 0.0), Color(1, 0.1, 0.1, a), Color(1, 0.1, 0.1, a)]))
		if Game.lava_dist < 200.0 and fmod(t, 0.5) < 0.3:
			_txt("RISE!", Vector2(0, 600), 44, Color("ff6b6b"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)

	_panel(Rect2(20, 16, 300, 112), Color(0.05, 0.03, 0.15, 0.6))
	_txt("HEIGHT", Vector2(36, 42), 16, Color("9aa5ff"))
	_txt("%d m" % Game.height, Vector2(36, 86), 40, Color.WHITE)
	_txt("SCORE  %d" % Game.get_score(), Vector2(36, 114), 20, Color("ffd23f"))

	_panel(Rect2(1000, 16, 260, 82), Color(0.05, 0.03, 0.15, 0.6))
	ctl.draw_circle(Vector2(1030, 46), 11.0, Color("b8860b"))
	ctl.draw_circle(Vector2(1030, 46), 9.0, Color("ffd23f"))
	_txt("x %d" % Game.coins, Vector2(1052, 54), 28, Color.WHITE)
	_txt("BEST  %d" % maxi(Game.best, Game.get_score()), Vector2(1018, 86), 18, Color("9aa5ff"))

	if Game.combo >= 2:
		var col := Color.from_hsv(fposmod(t * 0.6, 1.0), 0.5, 1.0)
		_txt("BOUNCE x%d" % Game.combo, Vector2(0, 110), int(46.0 + pop * 22.0), col, HORIZONTAL_ALIGNMENT_CENTER, 1280.0)

	# abilities
	_panel(Rect2(20, 628, 470, 72), Color(0.05, 0.03, 0.15, 0.6))
	var dc := Color("4dffea") if Game.dash_ready else Color(0.4, 0.4, 0.5)
	ctl.draw_circle(Vector2(50, 664), 14.0, dc)
	_txt("DASH [X]", Vector2(72, 671), 18, dc)
	_txt("HIGH JUMP [Z]", Vector2(200, 656), 16, Color.WHITE)
	_panel(Rect2(200, 664, 140, 12), Color(1, 1, 1, 0.12), 6)
	var rc := Color("7df9ff") if Game.hj_ratio >= 1.0 else Color("5a7fff")
	_panel(Rect2(200, 664, 140.0 * clampf(Game.hj_ratio, 0.0, 1.0), 12), rc, 6)
	var run_on := Input.is_action_pressed("run")
	_txt("RUN [SHIFT]", Vector2(366, 671), 18, Color("ffb02e") if run_on else Color(0.5, 0.5, 0.6))


func _title() -> void:
	var f := ThemeDB.fallback_font
	var title := "BOUNCE CLIMB"
	var fs := 92
	var total := f.get_string_size(title, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var x := 640.0 - total * 0.5
	for i in title.length():
		var ch := title.substr(i, 1)
		var cw := f.get_string_size(ch, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var y := 190.0 - absf(sin(t * 3.0 + float(i) * 0.45)) * 34.0
		var col := Color.from_hsv(fposmod(float(i) * 0.07 + t * 0.15, 1.0), 0.55, 1.0)
		_txt(ch, Vector2(x, y), fs, col)
		x += cw
	_txt("an infinite bouncy ascent", Vector2(0, 232), 24, Color("c9d1ff"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)

	var rows := [
		["MOVE", "A / D  or  Arrow Keys"],
		["RUN", "Hold SHIFT"],
		["JUMP", "SPACE / W  (hold = higher)"],
		["HIGH JUMP", "Z  (short cooldown)"],
		["DASH", "X  (once per airtime)"],
	]
	_panel(Rect2(330, 262, 620, 232), Color(0.05, 0.03, 0.16, 0.72), 18)
	for i in rows.size():
		var ry := 306.0 + float(i) * 38.0
		_txt(rows[i][0], Vector2(350, ry), 24, Color("ffd23f"), HORIZONTAL_ALIGNMENT_RIGHT, 210.0)
		_txt(rows[i][1], Vector2(584, ry), 24, Color.WHITE)
	_txt("Hold JUMP as you land on a pad or jelly platform to bounce HIGHER!", Vector2(0, 524), 22, Color("7df9ff"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	_txt("Chain bounces for COMBOS. Outrun the rising lava!", Vector2(0, 554), 22, Color("ff9ecb"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	if Game.best > 0:
		_txt("BEST SCORE  %d" % Game.best, Vector2(0, 596), 22, Color("9aa5ff"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	if fmod(t, 1.0) < 0.65:
		_txt("PRESS SPACE TO START", Vector2(0, 660), 36, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 1280.0)


func _gameover() -> void:
	ctl.draw_rect(Rect2(0, 0, 1280, 720), Color(0.03, 0.0, 0.1, 0.6))
	_panel(Rect2(380, 190, 520, 340), Color(0.07, 0.03, 0.2, 0.92), 22)
	_txt("YOU SANK!", Vector2(0, 262), 60, Color("ff6b8b"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	_txt("HEIGHT   %d m" % Game.height, Vector2(0, 328), 30, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	_txt("COINS   %d" % Game.coins, Vector2(0, 366), 30, Color("ffd23f"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	_txt("SCORE   %d" % Game.get_score(), Vector2(0, 410), 38, Color("7df9ff"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	if Game.get_score() >= Game.best and Game.get_score() > 0:
		_txt("NEW BEST!", Vector2(0, 448), 26, Color.from_hsv(fposmod(t, 1.0), 0.5, 1.0), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	else:
		_txt("BEST   %d" % Game.best, Vector2(0, 448), 24, Color("9aa5ff"), HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
	if fmod(t, 1.0) < 0.65:
		_txt("Press SPACE or R to bounce back", Vector2(0, 506), 26, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 1280.0)
