# Bounce Climb (Godot 4.2+)

Infinite, procedurally generated vertical platformer about BOUNCING.
Open `project.godot` in Godot 4.2 or newer and press F5.

## Controls
| Action | Keys | Gamepad |
|---|---|---|
| Move | A/D or Arrows | Left stick / D-pad |
| Run | Hold Shift | Right trigger / RB |
| Jump (hold = higher) | Space / W / Up | A |
| High Jump (cooldown) | Z / K | Y |
| Dash (once per airtime) | X / J | X / B |
| Restart | R / Enter | Start |

## Mechanics
- Hold JUMP when landing on a **spring pad** (red) or **jelly platform** (pink) to bounce higher.
- Chain bounces without touching solid ground for a **BOUNCE COMBO** (score bonus; coins are multiplied).
- Platforms: normal, moving, crumbling, jelly. Screen edges wrap around.
- Rising lava speeds up as you climb. Don't fall below the screen either.

Everything (graphics, sound) is generated in code; no external assets.
Best score is saved to `user://bounce_climb.cfg`.
